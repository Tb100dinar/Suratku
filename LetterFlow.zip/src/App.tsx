import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import Layout from './components/Layout';
import LoginPage from './components/LoginPage';
import SignupPage from './components/SignupPage';
import ForgotPassword from './components/ForgotPassword';
import Dashboard from './components/Dashboard';
import SuratMasukPage from './components/surat-masuk/SuratMasukPage';
import SuratKeluarPage from './components/surat-keluar/SuratKeluarPage';
import AdminPage from './components/admin/AdminPage';
import './index.css';

function App() {
  return (
    <Router>
      <Toaster position="top-right" />
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/signup" element={<SignupPage />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route
          path="/"
          element={
            <Layout>
              <Dashboard />
            </Layout>
          }
        />
        <Route
          path="/surat-masuk"
          element={
            <Layout>
              <SuratMasukPage />
            </Layout>
          }
        />
        <Route
          path="/surat-keluar"
          element={
            <Layout>
              <SuratKeluarPage />
            </Layout>
          }
        />
        <Route
          path="/admin"
          element={
            <Layout>
              <AdminPage />
            </Layout>
          }
        />
      </Routes>
    </Router>
  );
}

export default App;
