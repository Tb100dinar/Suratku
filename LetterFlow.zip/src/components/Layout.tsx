import { useEffect, useState } from 'react';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import { auth, db } from '../config/firebase';
import { LogOut, Mail, Send, Menu, House, Users, ChevronLeft } from 'lucide-react';
import { doc, getDoc } from 'firebase/firestore';

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const [isNavOpen, setIsNavOpen] = useState(true);
  const [userRole, setUserRole] = useState<'admin' | 'user' | null>(null);
  
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async (user) => {
      if (!user) {
        navigate('/login');
      } else {
        // Fetch user role from admin collection
        const adminDoc = await getDoc(doc(db, 'admin', user.uid));
        if (adminDoc.exists()) {
          setUserRole(adminDoc.data().kategori);
        }
      }
    });

    return () => unsubscribe();
  }, [navigate]);

  const handleLogout = async () => {
    try {
      await auth.signOut();
      navigate('/login');
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  const isActivePath = (path: string) => {
    return location.pathname === path;
  };

  return (
    <div className="min-h-screen flex bg-gray-50">
      {/* Sidebar */}
      <div className={`${isNavOpen ? 'w-64' : 'w-20'} bg-white shadow-lg transition-all duration-300 relative`}>
        {/* Toggle Button */}
        <button
          onClick={() => setIsNavOpen(!isNavOpen)}
          className="absolute -right-3 top-6 bg-white rounded-full p-1 shadow-md"
        >
          <ChevronLeft className={`h-4 w-4 text-gray-600 transition-transform duration-300 ${isNavOpen ? '' : 'rotate-180'}`} />
        </button>

        {/* Logo */}
        <div className="h-16 flex items-center px-6 border-b">
          <Menu className="h-6 w-6 text-indigo-600 mr-2" />
          {isNavOpen && <span className="text-xl font-bold text-gray-800">Aplikasi Surat</span>}
        </div>

        {/* Navigation Links */}
        <nav className="px-4 py-4">
          <div className="space-y-1">
            <Link
              to="/"
              className={`flex items-center px-4 py-2 text-sm font-medium rounded-md ${
                isActivePath('/') 
                  ? 'bg-indigo-50 text-indigo-600' 
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
              }`}
            >
              <House className="h-5 w-5" />
              {isNavOpen && <span className="ml-3">Dashboard</span>}
            </Link>

            {userRole === 'admin' && (
              <Link
                to="/admin"
                className={`flex items-center px-4 py-2 text-sm font-medium rounded-md ${
                  isActivePath('/admin')
                    ? 'bg-indigo-50 text-indigo-600'
                    : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                }`}
              >
                <Users className="h-5 w-5" />
                {isNavOpen && <span className="ml-3">Admin</span>}
              </Link>
            )}

            <Link
              to="/surat-masuk"
              className={`flex items-center px-4 py-2 text-sm font-medium rounded-md ${
                isActivePath('/surat-masuk')
                  ? 'bg-indigo-50 text-indigo-600'
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
              }`}
            >
              <Mail className="h-5 w-5" />
              {isNavOpen && <span className="ml-3">Surat Masuk</span>}
            </Link>

            <Link
              to="/surat-keluar"
              className={`flex items-center px-4 py-2 text-sm font-medium rounded-md ${
                isActivePath('/surat-keluar')
                  ? 'bg-indigo-50 text-indigo-600'
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
              }`}
            >
              <Send className="h-5 w-5" />
              {isNavOpen && <span className="ml-3">Surat Keluar</span>}
            </Link>
          </div>

          {/* Logout Button */}
          <div className="absolute bottom-4 w-full pr-8">
            <button
              onClick={handleLogout}
              className="flex items-center px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-50 hover:text-gray-900 rounded-md"
            >
              <LogOut className="h-5 w-5" />
              {isNavOpen && <span className="ml-3">Keluar</span>}
            </button>
          </div>
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1">
        <main className="py-6 px-8">
          {children}
        </main>
      </div>
    </div>
  );
}

// Export the layout and user role context
export const useUserRole = () => {
  const [userRole, setUserRole] = useState<'admin' | 'user' | null>(null);

  useEffect(() => {
    const fetchUserRole = async () => {
      const user = auth.currentUser;
      if (user) {
        const adminDoc = await getDoc(doc(db, 'admin', user.uid));
        if (adminDoc.exists()) {
          setUserRole(adminDoc.data().kategori);
        }
      }
    };

    fetchUserRole();
  }, []);

  return userRole;
};
