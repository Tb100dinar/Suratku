import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { auth, db } from '../config/firebase';
import toast from 'react-hot-toast';
import { CircleAlert } from 'lucide-react';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      // First sign in with Firebase Authentication
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      // Check admin status in Firestore
      const adminDoc = await getDoc(doc(db, 'admin', user.uid));
      
      if (!adminDoc.exists()) {
        await auth.signOut();
        toast.error('Akun tidak ditemukan dalam sistem');
        setIsLoading(false);
        return;
      }

      const adminData = adminDoc.data();
      
      // Check admin status
      if (adminData.status === 'menunggu' || adminData.status === 'pending') {
        await auth.signOut();
        toast.error('Akun Anda masih menunggu verifikasi dari admin');
        setIsLoading(false);
        return;
      }

      if (adminData.status === 'rejected') {
        await auth.signOut();
        toast.error('Akun Anda ditolak oleh admin. Silakan hubungi administrator.');
        setIsLoading(false);
        return;
      }

      if (adminData.status === 'diterima' || adminData.status === 'approved') {
        toast.success('Login berhasil');
        navigate('/');
      } else {
        await auth.signOut();
        toast.error('Status akun tidak valid');
        setIsLoading(false);
        return;
      }
    } catch (error: any) {
      let errorMessage = 'Login gagal. Periksa email dan password Anda.';
      
      if (error.code === 'auth/user-not-found') {
        errorMessage = 'Email tidak terdaftar';
      } else if (error.code === 'auth/wrong-password') {
        errorMessage = 'Password salah';
      } else if (error.code === 'auth/invalid-email') {
        errorMessage = 'Format email tidak valid';
      }
      
      toast.error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-10">
        <div>
          <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
            Login Aplikasi Surat
          </h2>
          <p className="mt-4 text-center text-sm text-gray-600">
            Masuk ke akun Anda untuk melanjutkan
          </p>
        </div>

        {/* Verification Notice */}
        <div className="rounded-md bg-yellow-50 p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <CircleAlert className="h-5 w-5 text-yellow-400" aria-hidden="true" />
            </div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-yellow-800">
                Perhatian
              </h3>
              <div className="mt-2 text-sm text-yellow-700">
                <p>
                  Akun baru perlu diverifikasi oleh admin sebelum dapat digunakan.
                  Silakan tunggu hingga akun Anda diverifikasi.
                </p>
              </div>
            </div>
          </div>
        </div>

        <form className="mt-8 space-y-8" onSubmit={handleLogin}>
          <div className="space-y-6">
            <div>
              <label htmlFor="email-address" className="block text-sm font-medium text-gray-700 mb-2">
                Email
              </label>
              <input
                id="email-address"
                name="email"
                type="email"
                autoComplete="email"
                required
                className="appearance-none block w-full px-3 py-3 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                placeholder="Masukkan email Anda"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={isLoading}
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-2">
                Password
              </label>
              <input
                id="password"
                name="password"
                type="password"
                autoComplete="current-password"
                required
                className="appearance-none block w-full px-3 py-3 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                placeholder="Masukkan password Anda"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={isLoading}
              />
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="text-sm">
              <Link to="/forgot-password" className="font-medium text-indigo-600 hover:text-indigo-500">
                Lupa password?
              </Link>
            </div>
          </div>

          <div>
            <button
              type="submit"
              disabled={isLoading}
              className="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? 'Logging in...' : 'Login'}
            </button>
          </div>
        </form>

        <div className="text-center mt-8">
          <p className="text-sm text-gray-600">
            Belum punya akun?{' '}
            <Link to="/signup" className="font-medium text-indigo-600 hover:text-indigo-500">
              Daftar disini
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
