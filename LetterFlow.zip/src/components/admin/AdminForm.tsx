import { useState, useEffect } from 'react';
import { collection, addDoc, doc, updateDoc, getDoc } from 'firebase/firestore';
import { createUserWithEmailAndPassword, updateEmail, updatePassword, getAuth } from 'firebase/auth';
import { db } from '../../config/firebase';
import { Admin } from '../../types';
import { X } from 'lucide-react';
import toast from 'react-hot-toast';

interface AdminFormProps {
  onClose: () => void;
  editData?: Admin | null;
  currentDataCount: number;
}

export default function AdminForm({ onClose, editData, currentDataCount }: AdminFormProps) {
  const [formData, setFormData] = useState({
    no: '',
    user_name: '',
    email: '',
    password: '',
    kategori: 'user' as 'user' | 'admin',
    status: 'menunggu' as 'menunggu' | 'diterima'
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (editData) {
      setFormData({
        no: editData.no,
        user_name: editData.user_name,
        email: editData.email || '',
        password: editData.password,
        kategori: editData.kategori,
        status: editData.status === 'pending' || editData.status === 'approved' ? 'diterima' : 'menunggu'
      });
    } else {
      setFormData(prev => ({
        ...prev,
        no: String(currentDataCount + 1).padStart(3, '0')
      }));
    }
  }, [editData, currentDataCount]);

  const validateEmail = (email: string) => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  };

  const validatePassword = (password: string) => {
    return password.length >= 6;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Validate email and password
      if (!validateEmail(formData.email)) {
        toast.error('Email tidak valid');
        setIsSubmitting(false);
        return;
      }

      if (!validatePassword(formData.password)) {
        toast.error('Password harus minimal 6 karakter');
        setIsSubmitting(false);
        return;
      }

      const auth = getAuth();

      if (editData) {
        // Update existing user
        const adminDoc = await getDoc(doc(db, 'admin', editData.id));
        if (!adminDoc.exists()) {
          throw new Error('Admin data tidak ditemukan');
        }

        const adminData = adminDoc.data();
        const currentUser = auth.currentUser;

        // Update authentication if email or password changed
        if (adminData.email !== formData.email && currentUser) {
          await updateEmail(currentUser, formData.email);
        }
        if (formData.password !== editData.password && currentUser) {
          await updatePassword(currentUser, formData.password);
        }

        // Update Firestore document
        await updateDoc(doc(db, 'admin', editData.id), {
          no: formData.no,
          user_name: formData.user_name,
          email: formData.email,
          password: formData.password,
          kategori: formData.kategori,
          status: formData.status,
          updatedAt: new Date().toISOString()
        });

        toast.success('Data admin berhasil diperbarui');
      } else {
        // Create new user
        const userCredential = await createUserWithEmailAndPassword(
          auth,
          formData.email,
          formData.password
        );

        // Store admin data in Firestore
        await addDoc(collection(db, 'admin'), {
          no: formData.no,
          user_name: formData.user_name,
          email: formData.email,
          password: formData.password,
          kategori: formData.kategori,
          status: formData.status,
          uid: userCredential.user.uid,
          createdAt: new Date().toISOString()
        });

        toast.success('Admin berhasil ditambahkan');
      }

      onClose();
    } catch (error: any) {
      let errorMessage = 'Terjadi kesalahan saat menyimpan data';

      if (error.code === 'auth/email-already-in-use') {
        errorMessage = 'Email sudah terdaftar';
      } else if (error.code === 'auth/invalid-email') {
        errorMessage = 'Format email tidak valid';
      } else if (error.code === 'auth/weak-password') {
        errorMessage = 'Password terlalu lemah';
      }

      toast.error(errorMessage);
      console.error('Error in AdminForm:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <div className="p-4 sm:p-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold">
          {editData ? 'Edit Admin' : 'Tambah Admin'}
        </h2>
        <button
          onClick={onClose}
          className="text-gray-500 hover:text-gray-700"
        >
          <X className="w-6 h-6" />
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">
            No
          </label>
          <input
            type="text"
            name="no"
            value={formData.no}
            onChange={handleChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            required
            readOnly
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            Username
          </label>
          <input
            type="text"
            name="user_name"
            value={formData.user_name}
            onChange={handleChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            Email
          </label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            Password
          </label>
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            required
            minLength={6}
          />
          <p className="mt-1 text-sm text-gray-500">
            Minimal 6 karakter
          </p>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            Kategori
          </label>
          <select
            name="kategori"
            value={formData.kategori}
            onChange={handleChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            required
          >
            <option value="user">User</option>
            <option value="admin">Admin</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            Status
          </label>
          <select
            name="status"
            value={formData.status}
            onChange={handleChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            required
          >
            <option value="menunggu">Menunggu</option>
            <option value="diterima">Diterima</option>
          </select>
        </div>

        <div className="flex justify-end space-x-3 mt-6">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
            disabled={isSubmitting}
          >
            Batal
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSubmitting ? 'Menyimpan...' : (editData ? 'Perbarui' : 'Simpan')}
          </button>
        </div>
      </form>
    </div>
  );
}
