import { useEffect, useState } from 'react';
import { collection, query, orderBy, getDocs, deleteDoc, doc, updateDoc } from 'firebase/firestore';
import { db } from '../../config/firebase';
import { Admin } from '../../types';
import { Plus, Trash2, Pencil, Search, CircleCheck, CircleX } from 'lucide-react';
import AdminForm from './AdminForm';
import BackupRestore from './BackupRestore';
import toast from 'react-hot-toast';

export default function AdminPage() {
  const [adminList, setAdminList] = useState<Admin[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [selectedAdmin, setSelectedAdmin] = useState<Admin | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const fetchAdmins = async () => {
    try {
      const q = query(collection(db, 'admin'), orderBy('createdAt', 'desc'));
      const querySnapshot = await getDocs(q);
      const admins = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as Admin));
      setAdminList(admins);
    } catch (error) {
      toast.error('Gagal mengambil data admin');
    }
  };

  useEffect(() => {
    fetchAdmins();
  }, []);

  const handleEdit = (admin: Admin) => {
    setSelectedAdmin(admin);
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Apakah Anda yakin ingin menghapus admin ini?')) {
      try {
        await deleteDoc(doc(db, 'admin', id));
        toast.success('Admin berhasil dihapus');
        fetchAdmins();
      } catch (error) {
        toast.error('Gagal menghapus admin');
      }
    }
  };

  const handleStatusChange = async (admin: Admin, newStatus: 'menunggu' | 'diterima') => {
    try {
      await updateDoc(doc(db, 'admin', admin.id), {
        status: newStatus,
        updatedAt: new Date().toISOString()
      });
      toast.success(`Status berhasil diubah menjadi ${newStatus}`);
      fetchAdmins();
    } catch (error) {
      toast.error('Gagal mengubah status');
    }
  };

  const handleFormClose = () => {
    setShowForm(false);
    setSelectedAdmin(null);
    fetchAdmins();
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'diterima':
      case 'approved':
        return <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">Diterima</span>;
      case 'menunggu':
      case 'pending':
        return <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">Menunggu</span>;
      case 'rejected':
        return <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">Ditolak</span>;
      default:
        return <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">-</span>;
    }
  };

  const filteredAdmins = adminList.filter(admin => {
    const searchTermLower = searchTerm.toLowerCase();
    return (
      admin.user_name.toLowerCase().includes(searchTermLower) ||
      admin.email.toLowerCase().includes(searchTermLower)
    );
  });

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Admin Management Section */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-bold">Manajemen Admin</h1>
                <button
                  onClick={() => setShowForm(true)}
                  className="flex items-center px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Tambah Admin
                </button>
              </div>

              <div className="mb-4">
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Cari admin..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                </div>
              </div>

              {showForm && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
                  <div className="bg-white rounded-lg w-full max-w-md">
                    <AdminForm
                      onClose={handleFormClose}
                      editData={selectedAdmin}
                      currentDataCount={adminList.length}
                    />
                  </div>
                </div>
              )}

              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">No</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Username</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Kategori</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredAdmins.map((admin) => (
                      <tr key={admin.id}>
                        <td className="px-6 py-4 whitespace-nowrap">{admin.no}</td>
                        <td className="px-6 py-4 whitespace-nowrap">{admin.user_name}</td>
                        <td className="px-6 py-4 whitespace-nowrap">{admin.email}</td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                            admin.kategori === 'admin' 
                              ? 'bg-green-100 text-green-800' 
                              : 'bg-yellow-100 text-yellow-800'
                          }`}>
                            {admin.kategori}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {getStatusBadge(admin.status)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex space-x-2">
                            {admin.status === 'menunggu' && (
                              <button
                                onClick={() => handleStatusChange(admin, 'diterima')}
                                className="text-green-600 hover:text-green-900"
                                title="Terima"
                              >
                                <CircleCheck className="w-4 h-4" />
                              </button>
                            )}
                            {admin.status === 'diterima' && (
                              <button
                                onClick={() => handleStatusChange(admin, 'menunggu')}
                                className="text-yellow-600 hover:text-yellow-900"
                                title="Kembalikan ke Menunggu"
                              >
                                <CircleX className="w-4 h-4" />
                              </button>
                            )}
                            <button
                              onClick={() => handleEdit(admin)}
                              className="text-indigo-600 hover:text-indigo-900"
                            >
                              <Pencil className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleDelete(admin.id)}
                              className="text-red-600 hover:text-red-900"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        {/* Backup Restore Section */}
        <div className="lg:col-span-1">
          <BackupRestore />
        </div>
      </div>
    </div>
  );
}
