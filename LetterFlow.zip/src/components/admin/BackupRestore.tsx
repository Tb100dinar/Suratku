import { useState } from 'react';
import { collection, getDocs, addDoc, setDoc, doc } from 'firebase/firestore';
import { db, auth } from '../../config/firebase';
import { Download, Upload, FileJson } from 'lucide-react';
import toast from 'react-hot-toast';

export default function BackupRestore() {
  const [isLoading, setIsLoading] = useState(false);

  const createBackup = async () => {
    setIsLoading(true);
    try {
      // Get all collections data
      const collections = ['admin', 'surat_masuk', 'surat_keluar'];
      const backupData: { [key: string]: any[] } = {};

      for (const collectionName of collections) {
        const querySnapshot = await getDocs(collection(db, collectionName));
        backupData[collectionName] = querySnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        }));
      }

      // Create backup file
      const timestamp = new Date().toISOString();
      const fileName = `backup_${timestamp.replace(/[:.]/g, '-')}.json`;
      const json = JSON.stringify(backupData, null, 2);
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);

      // Create download link
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      // Record backup in backup_restore collection
      await addDoc(collection(db, 'backup_restore'), {
        timestamp,
        type: 'backup',
        filename: fileName,
        admin: auth.currentUser?.email,
        status: 'success'
      });

      toast.success('Backup berhasil dibuat');
    } catch (error) {
      console.error('Backup error:', error);
      toast.error('Gagal membuat backup');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRestore = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsLoading(true);
    try {
      const reader = new FileReader();
      reader.onload = async (e) => {
        try {
          const backupData = JSON.parse(e.target?.result as string);
          
          // Restore each collection
          for (const [collectionName, documents] of Object.entries(backupData)) {
            if (Array.isArray(documents)) {
              for (const doc_data of documents) {
                const { id, ...data } = doc_data;
                await setDoc(doc(db, collectionName, id), data);
              }
            }
          }

          // Record restore in backup_restore collection
          await addDoc(collection(db, 'backup_restore'), {
            timestamp: new Date().toISOString(),
            type: 'restore',
            filename: file.name,
            admin: auth.currentUser?.email,
            status: 'success'
          });

          toast.success('Data berhasil direstore');
        } catch (error) {
          console.error('Restore error:', error);
          toast.error('File backup tidak valid');
        }
      };
      reader.readAsText(file);
    } catch (error) {
      console.error('Restore error:', error);
      toast.error('Gagal melakukan restore');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h2 className="text-xl font-semibold mb-4">Backup & Restore</h2>
      
      <div className="space-y-4">
        {/* Backup Button */}
        <div>
          <button
            onClick={createBackup}
            disabled={isLoading}
            className="flex items-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Download className="w-4 h-4 mr-2" />
            {isLoading ? 'Memproses...' : 'Backup Data'}
          </button>
          <p className="mt-1 text-sm text-gray-500">
            Download backup dari seluruh data aplikasi
          </p>
        </div>

        {/* Restore Section */}
        <div>
          <label className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 cursor-pointer disabled:opacity-50">
            <Upload className="w-4 h-4 mr-2" />
            <span>{isLoading ? 'Memproses...' : 'Restore Data'}</span>
            <input
              type="file"
              accept=".json"
              onChange={handleRestore}
              disabled={isLoading}
              className="hidden"
            />
          </label>
          <p className="mt-1 text-sm text-gray-500">
            Upload file backup untuk mengembalikan data
          </p>
        </div>

        {/* Instructions */}
        <div className="mt-6 p-4 bg-gray-50 rounded-md">
          <div className="flex items-start">
            <FileJson className="w-5 h-5 text-gray-400 mr-2 mt-0.5" />
            <div>
              <h3 className="text-sm font-medium text-gray-900">Petunjuk:</h3>
              <ul className="mt-2 text-sm text-gray-500 list-disc list-inside">
                <li>Backup akan menyimpan seluruh data dalam format JSON</li>
                <li>Pastikan file restore yang diupload adalah file backup yang valid</li>
                <li>Proses restore akan menimpa data yang ada saat ini</li>
                <li>Disarankan untuk melakukan backup secara berkala</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
