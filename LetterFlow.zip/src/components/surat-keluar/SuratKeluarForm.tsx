import { useState, useEffect } from 'react';
import { collection, addDoc, doc, updateDoc } from 'firebase/firestore';
import { db, auth } from '../../config/firebase';
import { SuratKeluar } from '../../types';
import { X } from 'lucide-react';
import toast from 'react-hot-toast';

interface SuratKeluarFormProps {
  onClose: () => void;
  editData?: SuratKeluar | null;
  currentDataCount: number;
}

export default function SuratKeluarForm({ onClose, editData, currentDataCount }: SuratKeluarFormProps) {
  const [formData, setFormData] = useState({
    kode_surat: '',
    nomor_surat: '',
    bagian: '',
    tanggal_surat: '',
    kepada: '',
    perihal: '',
    status: 'menunggu' as 'menunggu' | 'diterima',
    admin: ''
  });

  useEffect(() => {
    if (editData) {
      setFormData({
        kode_surat: editData.kode_surat,
        nomor_surat: editData.nomor_surat,
        bagian: editData.bagian,
        tanggal_surat: editData.tanggal_surat,
        kepada: editData.kepada,
        perihal: editData.perihal,
        status: editData.status,
        admin: editData.admin
      });
    }
  }, [editData]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const currentUser = auth.currentUser;
      if (!currentUser) {
        toast.error('Anda harus login terlebih dahulu');
        return;
      }

      const suratData = {
        ...formData,
        no_urut: editData ? editData.no_urut : String(currentDataCount + 1).padStart(3, '0'),
        admin: currentUser.email,
        createdAt: new Date().toISOString()
      };

      if (editData) {
        await updateDoc(doc(db, 'surat_keluar', editData.id), suratData);
        toast.success('Surat berhasil diperbarui');
      } else {
        await addDoc(collection(db, 'surat_keluar'), suratData);
        toast.success('Surat berhasil ditambahkan');
      }

      onClose();
    } catch (error) {
      toast.error('Terjadi kesalahan saat menyimpan surat');
    }
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <div className="p-4 sm:p-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold">
          {editData ? 'Edit Surat Keluar' : 'Tambah Surat Keluar'}
        </h2>
        <button
          onClick={onClose}
          className="text-gray-500 hover:text-gray-700"
        >
          <X className="w-6 h-6" />
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Kode Surat
            </label>
            <input
              type="text"
              name="kode_surat"
              value={formData.kode_surat}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Nomor Surat
            </label>
            <input
              type="text"
              name="nomor_surat"
              value={formData.nomor_surat}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Bagian
            </label>
            <input
              type="text"
              name="bagian"
              value={formData.bagian}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Tanggal Surat
            </label>
            <input
              type="date"
              name="tanggal_surat"
              value={formData.tanggal_surat}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Kepada
            </label>
            <input
              type="text"
              name="kepada"
              value={formData.kepada}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Status
            </label>
            <select
              name="status"
              value={formData.status}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              required
            >
              <option value="menunggu">Menunggu</option>
              <option value="diterima">Diterima</option>
            </select>
          </div>

          <div className="sm:col-span-2">
            <label className="block text-sm font-medium text-gray-700">
              Perihal
            </label>
            <textarea
              name="perihal"
              value={formData.perihal}
              onChange={handleChange}
              rows={3}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              required
            />
          </div>
        </div>

        <div className="flex justify-end space-x-3 mt-6">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
          >
            Batal
          </button>
          <button
            type="submit"
            className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            {editData ? 'Perbarui' : 'Simpan'}
          </button>
        </div>
      </form>
    </div>
  );
}
