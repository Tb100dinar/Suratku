import { useEffect, useState } from 'react';
import { collection, query, orderBy, getDocs, deleteDoc, doc } from 'firebase/firestore';
import { db } from '../../config/firebase';
import { SuratMasuk } from '../../types';
import { Plus, Trash2, Pencil, Search } from 'lucide-react';
import SuratMasukForm from './SuratMasukForm';
import toast from 'react-hot-toast';
import { useUserRole } from '../Layout';

export default function SuratMasukPage() {
  const [suratMasukList, setSuratMasukList] = useState<SuratMasuk[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [selectedSurat, setSelectedSurat] = useState<SuratMasuk | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const userRole = useUserRole();

  const fetchSuratMasuk = async () => {
    try {
      const q = query(collection(db, 'surat_masuk'), orderBy('createdAt', 'desc'));
      const querySnapshot = await getDocs(q);
      const suratList = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as SuratMasuk));
      setSuratMasukList(suratList);
    } catch (error) {
      toast.error('Gagal mengambil data surat masuk');
    }
  };

  useEffect(() => {
    fetchSuratMasuk();
  }, []);

  const handleEdit = (surat: SuratMasuk) => {
    if (userRole !== 'admin') {
      toast.error('Anda tidak memiliki akses untuk mengedit surat');
      return;
    }
    setSelectedSurat(surat);
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (userRole !== 'admin') {
      toast.error('Anda tidak memiliki akses untuk menghapus surat');
      return;
    }
    if (window.confirm('Apakah Anda yakin ingin menghapus surat ini?')) {
      try {
        await deleteDoc(doc(db, 'surat_masuk', id));
        toast.success('Surat berhasil dihapus');
        fetchSuratMasuk();
      } catch (error) {
        toast.error('Gagal menghapus surat');
      }
    }
  };

  const handleFormClose = () => {
    setShowForm(false);
    setSelectedSurat(null);
    fetchSuratMasuk();
  };

  const filteredSurat = suratMasukList.filter(surat => {
    const searchTermLower = searchTerm.toLowerCase();
    return (
      surat.nomor_surat.toLowerCase().includes(searchTermLower) ||
      surat.perihal.toLowerCase().includes(searchTermLower) ||
      surat.kepada.toLowerCase().includes(searchTermLower) ||
      surat.bagian.toLowerCase().includes(searchTermLower)
    );
  });

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
        <h1 className="text-2xl font-bold">Surat Masuk</h1>
        <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
          <div className="relative w-full sm:w-64">
            <input
              type="text"
              placeholder="Cari surat..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
          </div>
          {userRole === 'admin' && (
            <button
              onClick={() => setShowForm(true)}
              className="flex items-center justify-center px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 w-full sm:w-auto"
            >
              <Plus className="w-4 h-4 mr-2" />
              Tambah Surat Masuk
            </button>
          )}
        </div>
      </div>

      {showForm && userRole === 'admin' && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-lg w-full max-w-2xl my-8">
            <SuratMasukForm
              onClose={handleFormClose}
              editData={selectedSurat}
              currentDataCount={suratMasukList.length}
            />
          </div>
        </div>
      )}

      {/* Desktop View */}
      <div className="hidden md:block overflow-x-auto bg-white shadow-md rounded-lg">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">No Urut</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Kode Surat</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nomor Surat</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Bagian</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tanggal</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Kepada</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Perihal</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Admin</th>
              {userRole === 'admin' && (
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Aksi</th>
              )}
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredSurat.map((surat) => (
              <tr key={surat.id}>
                <td className="px-6 py-4 whitespace-nowrap">{surat.no_urut}</td>
                <td className="px-6 py-4 whitespace-nowrap">{surat.kode_surat}</td>
                <td className="px-6 py-4 whitespace-nowrap">{surat.nomor_surat}</td>
                <td className="px-6 py-4 whitespace-nowrap">{surat.bagian}</td>
                <td className="px-6 py-4 whitespace-nowrap">{surat.tanggal_surat}</td>
                <td className="px-6 py-4 whitespace-nowrap">{surat.kepada}</td>
                <td className="px-6 py-4 whitespace-nowrap">{surat.perihal}</td>
                <td className="px-6 py-4 whitespace-nowrap">{surat.admin}</td>
                {userRole === 'admin' && (
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex space-x-2">
                      <button
                        onClick={() => handleEdit(surat)}
                        className="text-indigo-600 hover:text-indigo-900"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(surat.id)}
                        className="text-red-600 hover:text-red-900"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile View */}
      <div className="md:hidden space-y-4">
        {filteredSurat.map((surat) => (
          <div key={surat.id} className="bg-white shadow rounded-lg p-4">
            <div className="flex justify-between items-start mb-2">
              <div>
                <span className="text-sm font-medium text-gray-500">No Urut:</span>
                <span className="ml-2">{surat.no_urut}</span>
              </div>
              {userRole === 'admin' && (
                <div className="flex space-x-2">
                  <button
                    onClick={() => handleEdit(surat)}
                    className="text-indigo-600 hover:text-indigo-900"
                  >
                    <Pencil className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(surat.id)}
                    className="text-red-600 hover:text-red-900"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
            
            <div className="space-y-2">
              <div>
                <span className="text-sm font-medium text-gray-500">Kode Surat:</span>
                <span className="ml-2">{surat.kode_surat}</span>
              </div>
              <div>
                <span className="text-sm font-medium text-gray-500">Nomor Surat:</span>
                <span className="ml-2">{surat.nomor_surat}</span>
              </div>
              <div>
                <span className="text-sm font-medium text-gray-500">Bagian:</span>
                <span className="ml-2">{surat.bagian}</span>
              </div>
              <div>
                <span className="text-sm font-medium text-gray-500">Tanggal:</span>
                <span className="ml-2">{surat.tanggal_surat}</span>
              </div>
              <div>
                <span className="text-sm font-medium text-gray-500">Kepada:</span>
                <span className="ml-2">{surat.kepada}</span>
              </div>
              <div>
                <span className="text-sm font-medium text-gray-500">Perihal:</span>
                <span className="ml-2">{surat.perihal}</span>
              </div>
              <div>
                <span className="text-sm font-medium text-gray-500">Admin:</span>
                <span className="ml-2">{surat.admin}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
