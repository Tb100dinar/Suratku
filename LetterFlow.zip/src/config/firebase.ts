import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyDyynGR8wO1NiNTXdV1alnkayoAgWelpWE",
  authDomain: "suratku-e83dd.firebaseapp.com",
  projectId: "suratku-e83dd",
  storageBucket: "suratku-e83dd.firebasestorage.app",
  messagingSenderId: "1053468905719",
  appId: "1:1053468905719:web:c39915ea406ebfbf7f83f2",
  measurementId: "G-X6X8YDCTL3"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
