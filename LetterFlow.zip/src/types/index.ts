export interface User {
  id: string;
  email: string;
  role: 'admin' | 'tamu';
}

export interface Admin {
  id: string;
  no: string;
  user_name: string;
  email: string;
  password: string;
  kategori: 'user' | 'admin';
  status: 'menunggu' | 'diterima' | 'pending' | 'approved' | 'rejected';
  uid?: string;
  createdAt?: string;
  updatedAt?: string;
  verifiedAt?: string;
}

export interface SuratMasuk {
  id: string;
  no_urut: string;
  kode_surat: string;
  nomor_surat: string;
  bagian: string;
  tanggal_surat: string;
  kepada: string;
  perihal: string;
  status: 'menunggu' | 'diterima';
  admin: string;
  createdAt: string;
}

export interface SuratKeluar {
  id: string;
  no_urut: string;
  kode_surat: string;
  nomor_surat: string;
  bagian: string;
  tanggal_surat: string;
  kepada: string;
  perihal: string;
  status: 'menunggu' | 'diterima';
  admin: string;
  createdAt: string;
}

export interface BackupRestore {
  id: string;
  timestamp: string;
  type: 'backup' | 'restore';
  filename: string;
  admin: string;
  status: 'success' | 'failed';
}
